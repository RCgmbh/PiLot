# PiLot
## PiLotWeb

The web GUI for the PiLot. This is to be placed usually in /var/www/html/pilot. 

**Configuration**

In /js/Config.js, the url to the REST API must be entered. 
